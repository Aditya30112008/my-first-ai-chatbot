"""
app.py
Streamlit UI for the RAG Document Q&A System.

Run with: streamlit run app.py
"""

import os
import tempfile

import streamlit as st
import anthropic
from dotenv import load_dotenv

from rag_engine import VectorStore, process_pdf, answer_question

load_dotenv()

st.set_page_config(page_title="Document Q&A (RAG)", page_icon="📄", layout="wide")

# ---------- Session state setup ----------
if "vector_store" not in st.session_state:
    st.session_state.vector_store = VectorStore()
if "chat_history" not in st.session_state:
    st.session_state.chat_history = []
if "uploaded_docs" not in st.session_state:
    st.session_state.uploaded_docs = []

# ---------- Sidebar: API key + document upload ----------
st.sidebar.title("⚙️ Setup")

api_key = st.sidebar.text_input(
    "Anthropic API Key",
    type="password",
    value=os.getenv("ANTHROPIC_API_KEY", ""),
    help="Get a key from console.anthropic.com. Stored only in this session, never saved.",
)

st.sidebar.divider()
st.sidebar.subheader("📁 Upload Documents")

uploaded_files = st.sidebar.file_uploader(
    "Upload PDF(s) — policies, manuals, contracts, reports",
    type=["pdf"],
    accept_multiple_files=True,
)

if uploaded_files:
    for uploaded_file in uploaded_files:
        if uploaded_file.name not in st.session_state.uploaded_docs:
            with st.sidebar.status(f"Processing {uploaded_file.name}..."):
                with tempfile.NamedTemporaryFile(delete=False, suffix=".pdf") as tmp:
                    tmp.write(uploaded_file.read())
                    tmp_path = tmp.name
                try:
                    chunk_count = process_pdf(
                        tmp_path, uploaded_file.name, st.session_state.vector_store
                    )
                    st.session_state.uploaded_docs.append(uploaded_file.name)
                    st.sidebar.success(f"✅ {uploaded_file.name} — {chunk_count} chunks indexed")
                except Exception as e:
                    st.sidebar.error(f"❌ Failed to process {uploaded_file.name}: {e}")
                finally:
                    os.unlink(tmp_path)

if st.session_state.uploaded_docs:
    st.sidebar.divider()
    st.sidebar.subheader("📚 Indexed Documents")
    for doc in st.session_state.uploaded_docs:
        st.sidebar.text(f"• {doc}")
    st.sidebar.caption(f"Total chunks in store: {st.session_state.vector_store.document_count()}")

    if st.sidebar.button("🗑️ Clear all documents"):
        st.session_state.vector_store.clear()
        st.session_state.uploaded_docs = []
        st.session_state.chat_history = []
        st.rerun()

# ---------- Main area ----------
st.title("📄 Document Q&A — RAG System")
st.caption(
    "Upload PDFs (policies, manuals, contracts) and ask questions. "
    "Answers are grounded strictly in the document content — no hallucinated outside knowledge."
)

if not st.session_state.uploaded_docs:
    st.info("👈 Upload at least one PDF in the sidebar to get started.")
else:
    # Display chat history
    for entry in st.session_state.chat_history:
        with st.chat_message("user"):
            st.write(entry["question"])
        with st.chat_message("assistant"):
            st.write(entry["answer"])
            with st.expander("📌 Sources used"):
                for src in entry["sources"]:
                    st.caption(f"**{src['source']}** (relevance: {src['score']:.2f})")
                    st.text(src["text"][:300] + ("..." if len(src["text"]) > 300 else ""))

    question = st.chat_input("Ask a question about your document(s)...")

    if question:
        if not api_key:
            st.error("Please enter your Anthropic API key in the sidebar first.")
        else:
            with st.chat_message("user"):
                st.write(question)

            with st.chat_message("assistant"):
                with st.spinner("Searching document and generating answer..."):
                    try:
                        client = anthropic.Anthropic(api_key=api_key)
                        result = answer_question(client, question, st.session_state.vector_store)
                        st.write(result["answer"])
                        with st.expander("📌 Sources used"):
                            for src in result["sources"]:
                                st.caption(f"**{src['source']}** (relevance: {src['score']:.2f})")
                                st.text(
                                    src["text"][:300] + ("..." if len(src["text"]) > 300 else "")
                                )
                        st.session_state.chat_history.append(
                            {
                                "question": question,
                                "answer": result["answer"],
                                "sources": result["sources"],
                            }
                        )
                    except Exception as e:
                        st.error(f"Error generating answer: {e}")

# ---------- Footer ----------
st.divider()
st.caption(
    "Built with Streamlit, ChromaDB (vector storage), Sentence-Transformers (embeddings), "
    "and Claude API (answer generation). A demonstration of Retrieval-Augmented Generation (RAG)."
)
