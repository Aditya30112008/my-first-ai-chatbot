"""
rag_engine.py
Core RAG (Retrieval-Augmented Generation) pipeline.

Pipeline stages:
1. Extract text from PDF
2. Split text into overlapping chunks
3. Generate embeddings for each chunk (using a local sentence-transformer model — free, no API cost)
4. Store embeddings in a local vector database (ChromaDB)
5. On query: embed the question, retrieve top-k most similar chunks
6. Pass retrieved chunks + question to Claude as context -> get grounded answer
"""

import os
import uuid
from typing import List, Dict

from pypdf import PdfReader
import chromadb
from chromadb.utils import embedding_functions
import anthropic


# ---------- 1. PDF TEXT EXTRACTION ----------

def extract_text_from_pdf(file_path: str) -> str:
    """Extract raw text from a PDF file, page by page."""
    reader = PdfReader(file_path)
    full_text = []
    for page_num, page in enumerate(reader.pages):
        text = page.extract_text() or ""
        if text.strip():
            full_text.append(f"[Page {page_num + 1}]\n{text}")
    return "\n\n".join(full_text)


# ---------- 2. CHUNKING ----------

def chunk_text(text: str, chunk_size: int = 800, overlap: int = 150) -> List[str]:
    """
    Split text into overlapping chunks.
    chunk_size: approx characters per chunk
    overlap: characters shared between consecutive chunks (preserves context across boundaries)
    """
    chunks = []
    start = 0
    text_length = len(text)

    while start < text_length:
        end = start + chunk_size
        chunk = text[start:end]
        chunks.append(chunk)
        start += chunk_size - overlap

    return [c.strip() for c in chunks if c.strip()]


# ---------- 3. VECTOR STORE (ChromaDB + local embedding model) ----------

class VectorStore:
    """
    Wraps ChromaDB with a local sentence-transformer embedding model
    (all-MiniLM-L6-v2 — small, fast, runs on CPU, completely free).
    """

    def __init__(self, persist_dir: str = "./chroma_store", collection_name: str = "documents"):
        self.client = chromadb.PersistentClient(path=persist_dir)
        self.embedding_fn = embedding_functions.SentenceTransformerEmbeddingFunction(
            model_name="all-MiniLM-L6-v2"
        )
        self.collection = self.client.get_or_create_collection(
            name=collection_name,
            embedding_function=self.embedding_fn,
        )

    def add_document(self, chunks: List[str], doc_name: str) -> int:
        """Add chunks from a document into the vector store. Returns number of chunks added."""
        ids = [str(uuid.uuid4()) for _ in chunks]
        metadatas = [{"source": doc_name, "chunk_index": i} for i in range(len(chunks))]
        self.collection.add(documents=chunks, ids=ids, metadatas=metadatas)
        return len(chunks)

    def query(self, question: str, top_k: int = 4) -> List[Dict]:
        """Retrieve the top_k most relevant chunks for a question."""
        results = self.collection.query(query_texts=[question], n_results=top_k)
        retrieved = []
        for doc, meta, dist in zip(
            results["documents"][0], results["metadatas"][0], results["distances"][0]
        ):
            retrieved.append({"text": doc, "source": meta["source"], "score": 1 - dist})
        return retrieved

    def clear(self):
        """Wipe the collection (useful when starting a fresh document)."""
        self.client.delete_collection(self.collection.name)
        self.collection = self.client.get_or_create_collection(
            name="documents", embedding_function=self.embedding_fn
        )

    def document_count(self) -> int:
        return self.collection.count()


# ---------- 4. ANSWER GENERATION (Claude API, grounded in retrieved chunks) ----------

SYSTEM_PROMPT = """You are a document Q&A assistant. You answer questions strictly based on \
the provided context chunks from a document. Rules:

1. Only use information present in the provided context. Never use outside knowledge.
2. If the context does not contain enough information to answer, say so clearly — \
do not guess or make up an answer.
3. When you answer, cite which page(s) the information came from if page numbers are visible \
in the context (e.g. "According to Page 3...").
4. Keep answers concise and directly responsive to the question.
"""


def generate_answer(client: anthropic.Anthropic, question: str, retrieved_chunks: List[Dict]) -> str:
    """Send retrieved context + question to Claude and get a grounded answer."""
    if not retrieved_chunks:
        return "No relevant content found in the document for this question."

    context_block = "\n\n---\n\n".join(
        f"[Source: {c['source']}]\n{c['text']}" for c in retrieved_chunks
    )

    user_message = f"""Context from the document:

{context_block}

---

Question: {question}

Answer the question using only the context above."""

    response = client.messages.create(
        model="claude-sonnet-4-6",
        max_tokens=1000,
        system=SYSTEM_PROMPT,
        messages=[{"role": "user", "content": user_message}],
    )
    return response.content[0].text


# ---------- 5. END-TO-END HELPERS ----------

def process_pdf(file_path: str, doc_name: str, vector_store: VectorStore) -> int:
    """Full ingestion pipeline: extract -> chunk -> embed -> store."""
    text = extract_text_from_pdf(file_path)
    if not text.strip():
        raise ValueError("No extractable text found in this PDF (it may be a scanned image).")
    chunks = chunk_text(text)
    count = vector_store.add_document(chunks, doc_name)
    return count


def answer_question(
    client: anthropic.Anthropic, question: str, vector_store: VectorStore, top_k: int = 4
) -> Dict:
    """Full query pipeline: retrieve -> generate -> return answer with sources."""
    retrieved = vector_store.query(question, top_k=top_k)
    answer = generate_answer(client, question, retrieved)
    return {"answer": answer, "sources": retrieved}
