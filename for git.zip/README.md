# 📄 Document Q&A — RAG System

**Ask questions about your PDFs (policies, manuals, contracts, reports) and get answers grounded strictly in the document content — not hallucinated from general knowledge.**

![Python](https://img.shields.io/badge/Python-3.10+-blue)
![Streamlit](https://img.shields.io/badge/Streamlit-UI-red)
![ChromaDB](https://img.shields.io/badge/ChromaDB-VectorStore-green)
![Claude API](https://img.shields.io/badge/Claude-Sonnet%204.6-orange)

---

## 🎯 The Problem

Employees and customers waste hours manually searching through long PDFs — HR policies, insurance documents, technical manuals, legal contracts — to find one specific answer. Ctrl+F only works if you know the exact wording. This project solves that: **upload any PDF, ask in plain English, get a precise answer with the exact source cited.**

This is a Retrieval-Augmented Generation (RAG) pattern — the same architecture used in production enterprise tools (internal knowledge bases, customer support bots, legal document review systems).

---

## 🏗️ Architecture

```
PDF Upload
    │
    ▼
Text Extraction (pypdf)
    │
    ▼
Chunking (800 chars, 150 overlap — preserves context across boundaries)
    │
    ▼
Embedding (sentence-transformers: all-MiniLM-L6-v2, runs locally, free)
    │
    ▼
Vector Storage (ChromaDB — persistent, local)
    │
    ▼
User asks a question
    │
    ▼
Question embedded → top-4 most relevant chunks retrieved (semantic similarity)
    │
    ▼
Retrieved chunks + question → Claude API (grounded answer generation)
    │
    ▼
Answer + cited sources displayed to user
```

**Key design decision:** Embeddings are generated locally with `sentence-transformers` instead of calling an embedding API for every chunk. This keeps ingestion fast and free — only the final answer-generation step calls the Claude API. This is a deliberate cost/latency optimization, not an oversight.

---

## ✨ Features

- Multi-PDF upload and indexing in a single session
- Persistent vector storage (documents stay indexed across app restarts)
- Source citation for every answer — click to see exactly which chunk and document it came from
- Relevance scoring shown for transparency (not a black box)
- Graceful handling of scanned/image-only PDFs (clear error instead of silent failure)
- Clear-and-restart option to index a fresh document set

---

## 🚀 Quick Start

```bash
# 1. Clone and enter the project
git clone <your-repo-url>
cd rag-doc-qa

# 2. Install dependencies
pip install -r requirements.txt

# 3. Set your Anthropic API key (or paste it in the sidebar at runtime)
export ANTHROPIC_API_KEY="your-key-here"

# 4. Run the app
streamlit run app.py
```

The app opens at `http://localhost:8501`. Upload a PDF in the sidebar, wait for indexing to finish, then ask questions in the chat box.

---

## 🧪 Example Use Case

Upload a company HR policy PDF and ask:
> "How many casual leaves am I entitled to per year?"

The system retrieves the exact clause from the policy document and answers citing the page number — instead of guessing based on generic HR knowledge.

---

## 🔧 Tech Stack

| Component | Tool | Why |
|---|---|---|
| PDF parsing | `pypdf` | Lightweight, no external dependencies |
| Embeddings | `sentence-transformers` (all-MiniLM-L6-v2) | Free, fast, runs on CPU — no API cost for indexing |
| Vector store | `ChromaDB` | Simple, persistent, no external database server needed |
| LLM | Claude API (claude-sonnet-4-6) | Strong instruction-following for "answer only from context" grounding |
| UI | Streamlit | Fast to build, good for demoing to non-technical stakeholders |

---

## 📈 Possible Extensions (next iteration ideas)

- Add OCR (e.g. `pytesseract`) to support scanned/image-only PDFs
- Swap ChromaDB for a hosted vector DB (Pinecone/Weaviate) for multi-user production deployment
- Add a RAG evaluation layer (Ragas/TruLens) to measure answer faithfulness and catch hallucinations
- Support additional file types: .docx, .txt, web URLs
- Add conversation memory so follow-up questions ("what about for new joinees?") resolve correctly

---

## ⚠️ Limitations (honest, not hidden)

- Scanned/image-only PDFs without embedded text will fail extraction (no OCR yet — listed above as a next step)
- Single-session vector store by default; for multi-user production use, this would need a hosted vector DB and proper user isolation
- Answer quality depends on chunk retrieval — very long, poorly structured documents may need tuned chunk size/overlap

---

## 📝 License

MIT — free to use, modify, and learn from.
